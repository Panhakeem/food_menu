const express = require("express")
const app = express()
const path = require("path")
const expressLayouts = require("express-ejs-layouts") // Import the middleware

app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))

app.use(expressLayouts) // Use the middleware
app.set("layout", "layout") // Set the default layout

app.use(express.static(path.join(__dirname, "public")))

const menuItems = [
  { name: "Pizza", description: "cheese pepperoni and basil", price: "$10" },
  {
    name: "Burger",
    description: "beef patty with onions and cheese",
    price: "$8",
  },
  {
    name: "Pasta",
    description: "bolognese pasta with beef meatballs",
    price: "$12",
  },
  {
    name: "Salad",
    description: "tuna salad with fresh assorted vegetables",
    price: "$7",
  },
]

app.get("/", (req, res) => {
  res.render("index", { menuItems })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`)
})
